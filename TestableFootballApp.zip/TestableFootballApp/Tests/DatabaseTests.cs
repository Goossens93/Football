﻿using System;
using System.Collections.Generic;
using System.Text;
using Database;
using DataStructures;
using Moq;
using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    class DatabaseTests
    {
        private Mock<ILoad> _mockLoader;
        private List<Player> _playerList;
        private CreateATeam _teamCreater;

        [SetUp]
        public void SetUp()
        {
            _playerList = new List<Player>();
            _mockLoader = new Mock<ILoad>();

            _mockLoader
                .Setup(p => p.Playerlist())
                .Returns(_playerList);

            _teamCreater = new CreateATeam(_mockLoader.Object);
        }

        [Test]
        public void LoaderShouldLoadTeam()
        {
            _teamCreater.CreateTeam();

            _mockLoader.Verify(p => p.Playerlist(),Times.Once);
        }
    }
}
