﻿using System.Collections.Generic;
using DataStructures;
using BusinessLogic;
using Database;
using NUnit.Framework;
using System;

namespace Tests
{
    [TestFixture]
    class TeamTests
    {
        private Match TheMatch;
        private MatchUtilities matchUtilities;
        private List<Player> TestTeam1;
        private List<Player> TestTeam2;
        private string TestTeam1Name;
        private string TestTeam2Name;

        [SetUp]
        public void SetUp()
        {
            CreateATeam TeamCreater = new CreateATeam(new DefaultTeam("TestTeam"));
            (TestTeam1, TestTeam1Name) = TeamCreater.CreateTeam();
            (TestTeam2, TestTeam2Name) = TeamCreater.CreateTeam();

            TheMatch = new Match(TestTeam1Name, TestTeam2Name, TestTeam1, TestTeam2);

            matchUtilities = new MatchUtilities(TheMatch);
        }

        [Test]
        public void TheChanceOnAChanceIsRealistic()
        {
            matchUtilities.CalculateMatchMath();

            Assert.True(0 < matchUtilities.HomeTeamSkills.ChancesPerMinute && matchUtilities.HomeTeamSkills.ChancesPerMinute < 1);
        }
    }
}
