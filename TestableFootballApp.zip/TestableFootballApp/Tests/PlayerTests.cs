using System;
using DataStructures;
using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class PlayerTests
    {
        private Player sut;

        [SetUp]
        public void SetUp()
        {
            sut = new Player("Henk", "KBB", 20, 20, 20);
        }

        [Test]
        public void CanCreatePlayer()
        {
            Assert.AreEqual(20, sut.Skills.Offense);
        }
    }
}
