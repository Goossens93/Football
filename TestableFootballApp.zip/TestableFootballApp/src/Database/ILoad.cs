﻿using System;
using System.Collections.Generic;
using DataStructures;
using System.Text;

namespace Database
{
    public interface ILoad
    {
        public string ClubName { get; set; }

        public void ILoad(string clubName)
        {
            ClubName = clubName;
        }

        List<Player> Playerlist();
    }
}
