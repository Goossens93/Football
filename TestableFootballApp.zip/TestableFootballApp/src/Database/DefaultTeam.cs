using DataStructures;
using System.Collections.Generic;

namespace Database
{
    public class DefaultTeam : ILoad
    {

        List<Player> defaultTeam = new List<Player>();

        public string ClubName { get; set; }

        public DefaultTeam(string clubName)
        {
            ClubName = clubName;
        }

        public List<Player> Playerlist()
        {
            for ( int i = 1; i < 12; i ++)
            {
                defaultTeam.Add(new Player($"player {i}", ClubName, 20, 20, 20));
            }
            return defaultTeam;
        }
    }
}