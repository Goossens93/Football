using System.Collections.Generic;
using DataStructures;

namespace Database

{
    public class LoadAjax : ILoad
    {
        public string ClubName { get; set; }

        public LoadAjax(string clubName)
        {
            ClubName = clubName;
        }

        public List<Player> Playerlist()
        {
            List<Player> Ajax = new List<Player>();

            Ajax.Add(new Player("Onana", ClubName, 0, 10, 80));
            Ajax.Add(new Player("Veltman", ClubName, 5, 75, 0));
            Ajax.Add(new Player("Schuurs", ClubName, 5, 75, 0));
            Ajax.Add(new Player("de Ligt", ClubName, 20, 80, 0));
            Ajax.Add(new Player("Tagliafigo", ClubName, 5, 80, 0));
            Ajax.Add(new Player("van de Beek", ClubName, 80, 80, 0));
            Ajax.Add(new Player("Blind", ClubName, 75, 80, 0));
            Ajax.Add(new Player("Ziyech", ClubName, 85, 70, 0));
            Ajax.Add(new Player("Neres", ClubName, 75, 10, 0));
            Ajax.Add(new Player("Tadic", ClubName, 80, 10, 0));
            Ajax.Add(new Player("Promes", ClubName, 80, 10, 0));

            return Ajax;
        }
    }
}