using System;
using System.Threading;

namespace UserInterface

{
    public class PrintOnConsole
    {
        string HomeTeam;
        string AwayTeam;

        public PrintOnConsole(string homeTeam, string awayTeam)
        {
            HomeTeam = homeTeam;
            AwayTeam = awayTeam;
        }

        int delay = 100; // milliseconds

        public void TheStartOfTheMatch()
        { System.Console.WriteLine($"Today's match will be between {HomeTeam} and {AwayTeam}"); }

        public void TheCurrentMinute(int minute)
        { 
            System.Console.WriteLine($"{minute}");
            Thread.Sleep(delay);
        }

        public void APotentialChance(bool ThereIsAChance, string Attacker, string AttackingTeam)
        {
            if (ThereIsAChance)
            {
                System.Console.WriteLine($"{Attacker} of {AttackingTeam} gets a chance!");

                Thread.Sleep(delay*10);
            }
        }

        public void APotentialGoal(bool ItIsAGoal, int HomeScore, int AwayScore)
        {
            if (ItIsAGoal)
            {
                System.Console.WriteLine($"He gets it past the keeper!");
                Thread.Sleep(delay*15);
                TheScore(HomeScore, AwayScore);
            }
            else
            {
                System.Console.WriteLine("He wastes the opportunity");
                Thread.Sleep(delay*10);
            }
        }

        public void HalfTime()
        { System.Console.WriteLine("Half-time"); }

        public void TheEndOfTheMatch(int HomeScore, int AwayScore)
        {
            System.Console.WriteLine("The match is over");
            TheScore(HomeScore, AwayScore);
        }

        public void TheScore(int HomeScore, int AwayScore)
        {
            System.Console.WriteLine($"The score is {HomeTeam} {HomeScore} : {AwayScore} {AwayTeam}");
            Thread.Sleep(delay*10);
        }
    }
}