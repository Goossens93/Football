using System.Collections.Generic;
using DataStructures;
using System.Threading;
using System;
using UserInterface;

namespace BusinessLogic
{
    public class MatchUtilities
    {
        List<Player> HomeTeam;
        List<Player> AwayTeam;
        string HomeTeamName;
        string AwayTeamName;

        public MatchUtilities(Match TheMatch)
        {
            HomeTeam = TheMatch.HomeTeam;
            AwayTeam = TheMatch.AwayTeam;
            HomeTeamName = TheMatch.HomeTeamName;
            AwayTeamName = TheMatch.AwayTeamName;
        }

        public TeamSkills HomeTeamSkills = new TeamSkills();
        public TeamSkills AwayTeamSkills = new TeamSkills();

        public void CalculateMatchMath()
        {
            HomeTeamSkills.CreateTeamStats(HomeTeam);
            AwayTeamSkills.CreateTeamStats(AwayTeam);

            HomeTeamSkills.CalculateChancesPerMinute(AwayTeamSkills);
            AwayTeamSkills.CalculateChancesPerMinute(HomeTeamSkills);

            double TotalChances = HomeTeamSkills.ChancesPerMinute + AwayTeamSkills.ChancesPerMinute;

            HomeTeamSkills.ChancesPerMinute /= TotalChances;
            AwayTeamSkills.ChancesPerMinute /= TotalChances;
        }

        public void PlayMatch(Match theMatch)
        {
            PrintOnConsole printOnConsole = new PrintOnConsole(HomeTeamName, AwayTeamName);
            printOnConsole.TheStartOfTheMatch();

            string AttackingTeam;
            string AttackingTeamName;
            bool ThereIsAChance;
            bool ItsAGoal;
            string Attacker;

            for (int minute = 1; minute < 91; minute++)
            {
                (AttackingTeam, AttackingTeamName, ThereIsAChance, ItsAGoal, Attacker) = ActionEveryMinute();

                printOnConsole.TheCurrentMinute(minute);

                if (ThereIsAChance)
                {
                    UpdateScore(ItsAGoal, AttackingTeam, theMatch);
                    printOnConsole.APotentialChance(ThereIsAChance, Attacker, AttackingTeamName);
                    printOnConsole.APotentialGoal(ItsAGoal, theMatch.HomeScore, theMatch.AwayScore);
                }

                if (minute == 45)
                {
                    printOnConsole.HalfTime();
                    printOnConsole.TheScore(theMatch.HomeScore, theMatch.AwayScore);
                }
            }
            printOnConsole.TheEndOfTheMatch(theMatch.HomeScore, theMatch.AwayScore);
        }

        public (string, string, bool, bool, string) ActionEveryMinute()
        {
            bool ThereIsAChance = IsThereAChance();
            bool ItsAGoal = false;

            if (ThereIsAChance)
            { 
                (string AttackingTeam, string AttackingTeamName) = WhichTeamGetsAChance();
                Player Attacker;

                Attacker = WhoGetsTheChance(AttackingTeam);
                ItsAGoal = WillHeScore(Attacker, AwayTeam[0]);
                return (AttackingTeam, AttackingTeamName, ThereIsAChance, ItsAGoal, Attacker.Name);
            }
            else
            { return ("None", "None", ThereIsAChance, ItsAGoal, "None"); }
        }

        public bool IsThereAChance()
        {
            Random ChangeGenerator = new Random();
            bool ThereIsAChance = false;

            if (ChangeGenerator.NextDouble() < .2)
            { ThereIsAChance = true; }

            return ThereIsAChance;            
        }

        public (string, string) WhichTeamGetsAChance()
        {
            Random ChangeGenerator = new Random();
            string AttackingTeam;
            string AttackingTeamName;

            if (ChangeGenerator.NextDouble() < HomeTeamSkills.ChancesPerMinute)
            { 
                AttackingTeam = "HomeTeam";
                AttackingTeamName = HomeTeamName;
            }
            else
            { 
                AttackingTeam = "AwayTeam";
                AttackingTeamName = AwayTeamName;
            }
            return (AttackingTeam, AttackingTeamName);
        }

        public Player WhoGetsTheChance(string AttackingTeamName)
        {
            List<Player> AttackingTeam;
            TeamSkills teamSkills;
            if ( AttackingTeamName == "HomeTeam")
            { 
                AttackingTeam = HomeTeam;
                teamSkills = HomeTeamSkills;
            }
            else
            {
                AttackingTeam = AwayTeam;
                teamSkills = AwayTeamSkills;
            }

            Random GoalChancePosition = new Random();
            int goalChancePosition = GoalChancePosition.Next(teamSkills.TotalOffense);

            Player HeGetsTheChance = new Player();
            int playerPosition = 0;

            foreach (Player player in AttackingTeam)
            {
                playerPosition += player.Skills.Offense;
                if (playerPosition >= goalChancePosition)
                {
                    HeGetsTheChance = player;
                    break;
                }
            }
            return HeGetsTheChance;
        }

        public bool WillHeScore(Player Attacker, Player Keeper)
        {
            bool ItsAGoal = false;
            Random PlayerActions = new Random();

            int KeepersDive = PlayerActions.Next(Keeper.Skills.Keeping);
            int AttackerShot = PlayerActions.Next(Attacker.Skills.Offense);

            if (AttackerShot > KeepersDive)
            { ItsAGoal = true; }

            return ItsAGoal;
        }

        public void UpdateScore(bool ItsAGoal, string AttackingTeam, Match TheMatch)
        {
            if (ItsAGoal)
            {
                if (AttackingTeam == "HomeTeam")
                { TheMatch.HomeScore++; }
                else
                { TheMatch.AwayScore++; }
            }
        }
    }
}