﻿using System.Collections.Generic;
using DataStructures;
using Database;

namespace BusinessLogic
{
    class Program
    {
        static void Main(string[] args)
        {
            CreateATeam TeamCreater = new CreateATeam(new DefaultTeam("DefaultTeam"));
            (List<Player> HomeTeam, string HomeTeamName) = TeamCreater.CreateTeam();
            (List<Player> AwayTeam, string AwayTeamName) = TeamCreater.CreateTeam();

            Match TheMatch = new Match(HomeTeamName, AwayTeamName, HomeTeam, AwayTeam);
            MatchUtilities matchUtilities = new MatchUtilities(TheMatch);
            matchUtilities.CalculateMatchMath();

            matchUtilities.PlayMatch(TheMatch);
        }
    }
}
