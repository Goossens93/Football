using System.Collections.Generic;
using DataStructures;
using Database;

namespace Database
{
    public class CreateATeam
    {
        private readonly ILoad _loader;

        public CreateATeam(ILoad loader)
        {
            _loader = loader;
        }

        public (List<Player>, string) CreateTeam()
        {
            return (_loader.Playerlist(), _loader.ClubName);
        }
    }
}