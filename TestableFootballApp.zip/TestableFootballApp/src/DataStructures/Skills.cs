namespace DataStructures

{
    public class Skills
    {
        public int Offense { get; set; }
        public int Defense { get; set; }
        public int Keeping { get; set; }
        public Skills()
        {}
        public void SetSkills(int offense, int defense, int keeping)
        {
            Offense = offense;
            Defense = defense;
            Keeping = keeping;
        }
    }
}