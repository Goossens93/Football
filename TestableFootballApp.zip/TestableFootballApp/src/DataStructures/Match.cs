using System.Collections.Generic;

namespace DataStructures

{
    public class Match
    {
        public string HomeTeamName { get; set; }
        public string AwayTeamName { get; set; }
        public List<Player> HomeTeam { get; set; }
        public List<Player> AwayTeam { get; set; }
        public Match(string homeTeamName, string awayTeamName, List<Player> homeTeam, List<Player> awayTeam)
        {
            HomeTeamName = homeTeamName;
            AwayTeamName = awayTeamName;
            HomeTeam = homeTeam;
            AwayTeam = awayTeam;
        }
        public int HomeScore = 0;
        public int AwayScore = 0;
    }
}