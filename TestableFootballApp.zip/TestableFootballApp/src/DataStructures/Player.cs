﻿namespace DataStructures

{
    public class Player
    {
        public string Name { get; set; }
        public string Club { get; set; }
        public Skills Skills = new Skills();

        public Player()
        {}

        public Player(string name, string clubName, int offense, int defense, int keeping)
        {
            Skills.SetSkills(offense, defense, keeping); 
            Name = name;
            Club = clubName;
        }
    }
}
