using System.Collections.Generic;
using System.Linq;

namespace DataStructures

{
    public class TeamSkills
    {
        public double Offense;
        public double Defense;
        public double Keeping;
        public int TotalOffense;

        public double ChancesPerMinute;
        
        public void CreateTeamStats(List<Player> OwnTeam)
        {
            Offense = OwnTeam.GetRange(8, 3).Select(i => i.Skills.Offense).Sum() + 0.55 * OwnTeam.GetRange(5, 3).Select(i => i.Skills.Offense).Sum() + 0.1 * OwnTeam.GetRange(1, 4).Select(i => i.Skills.Offense).Sum();
            Defense = OwnTeam.GetRange(1, 4).Select(i => i.Skills.Defense).Sum() + 0.55 * OwnTeam.GetRange(5, 3).Select(i => i.Skills.Defense).Sum() + 0.1 * OwnTeam.GetRange(8, 3).Select(i => i.Skills.Defense).Sum();
            Keeping = OwnTeam.First().Skills.Keeping;
            TotalOffense = OwnTeam.Select(i => i.Skills.Offense).Sum();
        }

        public void CalculateChancesPerMinute(TeamSkills Opponent)
        {
            ChancesPerMinute = Offense / Opponent.Defense * .1;
        }
    }
}